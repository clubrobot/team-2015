/*
 * Test.h
 *
 *  Created on: 9 févr. 2016
 *      Author: gab
 */

#ifndef TEST_H_
#define TEST_H_

#include "../Module.h"
#include <iostream>

class Test : public Module {
public:
	Test( uint8_t address, TCPClient& client );
	virtual ~Test();

protected:
	virtual void run();
};

#endif /* TEST_H_ */
